#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把真实 V5.4 原始 D2C 深度 .npy 另存为可视 PNG；绝不修改原始深度。"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np


def hash_file(f):
    h = hashlib.sha256()
    with f.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--capture', required=True, type=Path,
                        help='原始数据目录 .../attempt_01')
    parser.add_argument('--out', required=True, type=Path,
                        help='在原始 attempt 外另存新文件，例如 /home/abc/桌面/depth_preview_NOT_METRIC.png')
    args = parser.parse_args()
    capture = args.capture.expanduser().resolve(strict=True)
    out = args.out.expanduser().absolute()
    if not capture.is_dir() or not capture.name.startswith('attempt_'):
        raise RuntimeError('采集源路径必须为 attempt_XX')
    if capture == out.parent.resolve() or out.exists() or out.is_symlink():
        raise RuntimeError('禁止在原 attempt 内写新文件，或覆盖已有文件')
    if not out.parent.is_dir():
        raise RuntimeError('图片输出父目录不存在')
    mfile = capture / 'capture_manifest.json'
    done = json.loads((capture/'CAPTURE_COMPLETE.json').read_text(encoding='utf-8'))
    if done.get('sha256_capture_manifest') != hash_file(mfile):
        raise RuntimeError('manifest 完整性失败')
    manifest = json.loads(mfile.read_text(encoding='utf-8'))
    file = capture/'d2c_depth_raw.npy'
    if file.is_symlink() or hash_file(file) != manifest.get('source_files_sha256',{}).get('d2c_depth_raw.npy'):
        raise RuntimeError('depth 原始文件 SHA256 不匹配')
    raw = np.load(file, allow_pickle=False)
    if raw.shape != (480, 640) or raw.dtype != np.dtype('uint16'):
        raise RuntimeError('D2C 数据格式不是 480x640 uint16')
    scale = float(manifest['depth_scale_mm_per_raw'])
    if not (0 < scale < 100) or not np.isfinite(scale):
        raise RuntimeError('深度比例无效')
    valid = (raw > 0) & (raw < 65535)
    if not valid.any():
        raise RuntimeError('本帧没有有效深度')
    depth_mm = raw.astype(np.float64) * scale
    lo, hi = [float(x) for x in np.percentile(depth_mm[valid], [5,95])]
    if hi <= lo:
        hi = lo + 1
    gray = np.uint8(np.rint(np.clip((depth_mm - lo)/(hi-lo),0,1)*255))
    colored = cv2.applyColorMap(gray, cv2.COLORMAP_TURBO)
    colored[~valid] = (0,0,0)
    good, png = cv2.imencode('.png', colored)
    if not good or png is None:
        raise RuntimeError('PNG 编码失败')
    with out.open('xb') as f:
        f.write(png.tobytes())
    print('DEPTH_PREVIEW_CREATED_NOT_METRIC:', out)
    print('VALID_FRACTION:',round(float(valid.mean()),6), 'DEPTH_SCALE_MM_PER_RAW:',scale)
    print('DISPLAY_PERCENTILE_5_95_MM:',round(lo,3),round(hi,3))
    print('ORIGINAL_DEPTH_UNCHANGED:',file)
    print('IMPORTANT: PNG是每帧独立拉伸的伪彩预览，不能读出精确毫米；用原NPY和比例计算')
    return 0


if __name__=='__main__':
    try:
        sys.exit(main())
    except (OSError,ValueError,RuntimeError,KeyError) as exc:
        print('DEPTH_PREVIEW_STOP:',type(exc).__name__,str(exc),file=sys.stderr)
        sys.exit(2)
