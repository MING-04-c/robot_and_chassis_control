#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V5.4 相机专用入口：复用冻结的原始 camera_only()，绝不重新实现 SDK。

用法：python -B capture_gearbox_rgbd_camera_only_v54.py [--max-capture-attempts 3]
该文件所在目录必须同时包含冻结 V5.4 的 5 个相机模块。
不运行 U-Net，不生成 XYZ，不发送任何机器人动作。
"""
import sys
from run_paint_rgbd_unet_v5_4 import camera_only

if __name__ == "__main__":
    sys.exit(camera_only(sys.argv[1:]))
